# Eagle Library

this project aims to create a library containing schematics and foot prints for electronic components.

## Changelogs
2019-09-01 - Initial commit
+ Added Wemos Lolin D32 boards
+ Added Arduino Mega 2560 Rev 3

## -------------------------------
Feel free to use and share this library. 
